// Agrega estrellitas al mover el mouse
document.addEventListener("mousemove", (e) => {
  const star = document.createElement("div");
  star.className = "star";
  star.style.left = e.pageX + "px";
  star.style.top = e.pageY + "px";
  document.body.appendChild(star);
  setTimeout(() => star.remove(), 500);
});

// Tilt: requiere librería externa
VanillaTilt.init(document.querySelector(".tilt"), {
  max: 15,
  speed: 400,
  glare: true,
  "max-glare": 0.2
});

// Música toggle
const music = document.getElementById("bg-music");
const btn = document.getElementById("playMusic");
let playing = false;

function tryPlay() {
  music.play().then(() => {
    playing = true;
    btn.textContent = "⏸ Pause Music";
  }).catch(() => {});
}

btn.addEventListener("click", () => {
  if (playing) {
    music.pause();
    btn.textContent = "▶ Play Music";
  } else {
    tryPlay();
  }
  playing = !playing;
});

document.addEventListener("DOMContentLoaded", tryPlay);
